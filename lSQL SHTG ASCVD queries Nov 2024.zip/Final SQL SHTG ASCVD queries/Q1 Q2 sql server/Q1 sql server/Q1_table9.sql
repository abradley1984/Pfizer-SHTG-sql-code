/* T9 - risk factors, only for Q1.
   This is not currently saving to file but could be.


 */

select *
into #pat_list
from (select patid, cohort, TG_DATE

      from foo.dbo.shtg_Q1_cohort_with_exclusions
         -- fetch first 100 rows only
     ) as pcTD;
select *
into #labs_all
from (select * from foo.dbo.Q1_labs_all) as [Q1la*];
select *
into #labs
from (select patid,
             cohort,
             uacr,
             egfr_2021,
             nhdl,
             hscrp,
             IIF((egfr_2021 < 60 or uacr >= 30), 1, 0) as microvascular_disease,
             IIF((nhdl > 130), 1, 0)                   as nhdl_over_130,
             IIF((hscrp >= 3), 1, 0)                   as hscrp_over_3

      from #labs_all) as la;
select *
into #smoking
from (
         select patid, IIF(smoking in ('01', '02', '05', '07', '08'), 1, 0) as current_smoker
         from (
                  select a.patid,
                         row_number() OVER (
                             PARTITION BY a.patid
                             ORDER BY measure_date desc
                             )      row_num,
                         smoking as smoking,
                         cohort
                  from #pat_list a
                           left join cdm.dbo.vital b on a.patid = b.patid
                  WHERE smoking IS NOT NULL
                    AND not smoking in ('NI', 'OT', 'UN')) a
         where row_num = 1) as pcs;
select *
into #age_65
from (
         select patid, cohort, IIF(age > 65, 1, 0) as age_over_65
         from foo.dbo.shtg_Q1_cohort_with_exclusions) as p;
select *
into #retinopathy
from (
         select distinct a.patid,
                         a.cohort,
                         'retinopathy' as Comorbidity_name,
                         1             as retinopathy


         from #pat_list a
                  INNER JOIN cdm.dbo.diagnosis b on a.patid = b.patid
         where b.admit_date<='2021-09-30' and (dx IN ('H31.021',--RETINOPATHY
                       'H31.022',
                       'H31.023',
                       'H31.029',
                       'H35.00',
                       'H35.021',
                       'H35.022',
                       'H35.023',
                       'H35.029',
                       'H35.031',
                       'H35.032',
                       'H35.033',
                       'H35.039',
                       'H35.20',
                       'H35.21',
                       'H35.22',
                       'H35.23',
                       'H35.711',
                       'H35.712',
                       'H35.713',
                       'H35.719')
                   )
         group by a.patid, a.cohort) as ab;
select *
into #diabetes_10y
from (
         select distinct pats.patid,
                         pats.cohort,
                         'diabetes_10y' as Comorbidity_name,
                         1              as diabetes_10y

         from #pat_list pats
                  INNER JOIN cdm.dbo.diagnosis b on pats.patid = b.patid
         where (dx like 'E08%' -- diabetes

             OR dx like 'E09%' -- diabetes

             OR dx like 'E10%' -- diabetes

             OR dx like 'E11%' -- diabetes

             OR dx like 'E13%' -- diabetes

             OR dx like '249%' -- diabetes

             OR dx like '250%' -- diabetes
             )
           and b.admit_date
             < '2019-04-01'
         group by pats.patid, pats.cohort, b.admit_date
     ) as pb;

--TIA in last 5 years
select *
into #TIA
from (
         select distinct pats.patid,
                         pats.cohort,
                         'TIA' as Comorbidity_name,
                         1     as TIA

         from #pat_list pats
                  INNER JOIN cdm.dbo.diagnosis como on pats.patid = como.patid
         where (dx LIKE 'G45%' --'TIA'
             OR dx LIKE '435%' --'TIA'
             )
           and admit_date BETWEEN '2016-09-30' AND '2021-09-30'
         group by pats.patid, pats.cohort
     ) as pc;
select *
into #PAD
from (
         select distinct pats.patid,
                         pats.cohort,
                         'PAD' as Comorbidity_name,
                         1     as PAD

         from #pat_list pats
                  INNER JOIN cdm.dbo.diagnosis como on pats.patid = como.patid
         where  como.admit_date<='2021-09-30' and
         (dx in
                ('440.20', '440.21', '440.22', '440.23', '440.24', '440.29', '440.30', '440.31', '440.32', '440.4',
                 'I70.0', 'I70.1', 'I70.201', 'I70.202', 'I70.203', 'I70.208', 'I70.209', 'I70.21', 'I70.22', 'I70.232',
                 'I70.24', 'I70.25', 'I70.26', 'I70.261', 'I70.262', 'I70.263', 'I70.268', 'I70.269', 'I70.291',
                 'I70.292', 'I70.293', 'I70.298', 'I70.299', 'I70.3', 'I70.4', 'I70.5', 'I70.8', 'I70.90', 'I70.91',
                 'I70.92')-- PAD
                   )
             /* and admit_date BETWEEN '2020-09-30' AND '2021-09-30'*/
         group by pats.patid, pats.cohort
     ) as pc;
select *
into #CAD
from (
         select distinct pats.patid,
                         pats.cohort,
                         'CAD' as Comorbidity_name,
                         1     as CAD


         from #pat_list pats
                  INNER JOIN cdm.dbo.diagnosis como on pats.patid = como.patid
         where  como.admit_date<='2021-09-30' and (dx IN ('Z95.1', 'Z95.5', 'Z98.61')

                   -- MULTIVESSEL CAD
                   )
         group by pats.patid, pats.cohort
     ) as pc;
select *
into #MI
from (
         select distinct pats.patid,
                         pats.cohort,
                         'MI'                                                as Comorbidity_name,
                         1                                                   as MI,
                         max(admit_date)                                     as max_admit_date,
                         min(admit_date)                                     as min_admit_date,
                         abs(datediff(dd, max(admit_date), min(admit_date))) as MI_gap,
                         count(distinct admit_date)                          as count_admit

         from #pat_list pats
                  INNER JOIN cdm.dbo.diagnosis como on pats.patid = como.patid
         where  como.admit_date<='2021-09-30' and (dx like '410%' -- MI

             OR dx = '411.0' -- MI

             OR dx = '411.81' -- MI

             OR dx = '412' -- MI

             OR dx like 'I21%' -- MI

             OR dx like 'I22%' -- MI

             OR dx like '123%' -- MI


-- ?? IN SPREADSHEET FOR I24 AND I25

--OR dx = 'I24.0' -- MI

             OR dx = 'I25.2' -- MI)
                   )
         group by pats.patid, pats.cohort
     ) as pc;
select *
into #subsequent_MI
from (
         select distinct pats.patid,
                         pats.cohort,
                         'MI'                                                as Comorbidity_name,
                         1                                                   as MI,
                         max(admit_date)                                     as max_admit_date,
                         min(admit_date)                                     as min_admit_date,
                         abs(datediff(dd, max(admit_date), min(admit_date))) as MI_gap,
                         count(distinct admit_date)                          as count_admit,
                         max(IIF(dx like 'I22%', 1, 0))                      as subsequent_MI_I22

         from #pat_list pats
                  INNER JOIN cdm.dbo.diagnosis como on pats.patid = como.patid
         where  como.admit_date<='2021-09-30' and/*((dx like '410%' -- MI

             OR dx like 'I21%' -- MI
                    )
             and not pdx = 'S')

            OR*/ dx like 'I22%' -- MI subsequent

--removed complications, old MI codes for second MI


         group by pats.patid, pats.cohort
     ) as pc;
select *
into #stroke
from (
         select pats.patid,
                pats.cohort,
                'stroke'                                            as Comorbidity_name,
                1                                                   as stroke,
                max(admit_date)                                     as max_admit_date,
                min(admit_date)                                     as min_admit_date,
                abs(datediff(dd, max(admit_date), min(admit_date))) as stroke_gap

         from #pat_list pats
                  INNER JOIN cdm.dbo.diagnosis como on pats.patid = como.patid
         where  como.admit_date<='2021-09-30' and (
                       dx like '433%' -- STROKE

                       OR dx like '434%' -- STROKE

                       OR dx = '997.02' -- STROKE

                       OR dx like 'I63%' -- STROKE

                       OR dx like 'I97.8%' -- STROKE

                   )
         group by pats.patid, pats.cohort
     ) as pc;
select *
into #PCI
from (
         select a.patid,
                a.cohort,
                'PCI'                                               as Comorbidity_name,
                1                                                   as PCI,
                max(admit_date)                                     as max_admit_date,
                min(admit_date)                                     as min_admit_date,
                abs(datediff(dd, max(admit_date), min(admit_date))) as PCI_gap
         from #pat_list a
                  left join cdm.dbo.procedures b on a.patid = b.patid
         where  b.admit_date<='2021-09-30' and
         PX in ('92920', '92921', '92924', '92925', '92928', '92929', '92933', '92934', '92937', '92938', '92941',
                      '92943', '92944', '92973', '92974', '92975', '92978', '92979', '93571', '93572', 'C9600', 'C9601',
                      'C9602', 'C9603', 'C9604', 'C9605', 'C9606', 'C9607', 'C9608')
         group by a.patid, a.cohort) as ab;
select *
into #statins
from (
         select distinct a.patid, a.cohort, 1 as Statin
         from #pat_list a
                  left join cdm.dbo.prescribing b on a.patid = b.patid

         where b.rx_order_Date BETWEEN '2020-09-30' AND '2021-09-30'
             and rxnorm_cui in
                ('6472',
                        '36567',
                        '41127',
                        '42463',
                        '72875',
                        '83366',
                        '83367',
                        '103918',
                        '103919',
                        '104490',
                        '104491',
                        '151972',
                        '152923',
                        '153165',
                        '153302',
                        '153303',
                        '196503',
                        '197903',
                        '197904',
                        '197905',
                        '198211',
                        '200345',
                        '203144',
                        '203333',
                        '206257',
                        '206258',
                        '208220',
                        '209013',
                        '213319',
                        '215567',
                        '221072',
                        '224938',
                        '259255',
                        '261244',
                        '262095',
                        '284424',
                        '284764',
                        '301542',
                        '309123',
                        '309124',
                        '309125',
                        '310404',
                        '310405',
                        '312961',
                        '312962',
                        '313936',
                        '314231',
                        '320864',
                        '323828',
                        '327008',
                        '352387',
                        '352420',
                        '359731',
                        '359732',
                        '360507',
                        '404011',
                        '404013',
                        '404773',
                        '404914',
                        '433848',
                        '433849',
                        '476345',
                        '476349',
                        '476350',
                        '476351',
                        '484211',
                        '495215',
                        '541841',
                        '582041',
                        '582042',
                        '582043',
                        '596723',
                        '597967',
                        '597971',
                        '597974',
                        '597977',
                        '597980',
                        '597984',
                        '597987',
                        '597990',
                        '597993',
                        '617310',
                        '617311',
                        '617312',
                        '617314',
                        '617318',
                        '617320',
                        '644112',
                        '687048',
                        '750196',
                        '750199',
                        '750200',
                        '750203',
                        '750204',
                        '750207',
                        '750208',
                        '750211',
                        '750212',
                        '750215',
                        '750216',
                        '750219',
                        '750220',
                        '750223',
                        '750224',
                        '750227',
                        '750228',
                        '750231',
                        '750232',
                        '750235',
                        '750236',
                        '750239',
                        '757733',
                        '757736',
                        '757745',
                        '757748',
                        '761907',
                        '761909',
                        '762970',
                        '763225',
                        '763228',
                        '763229',
                        '763232',
                        '763233',
                        '763236',
                        '791831',
                        '791834',
                        '791835',
                        '791838',
                        '791839',
                        '791842',
                        '791843',
                        '791846',
                        '803516',
                        '859419',
                        '859421',
                        '859424',
                        '859426',
                        '859747',
                        '859749',
                        '859751',
                        '859753',
                        '861612',
                        '861634',
                        '861640',
                        '861643',
                        '861646',
                        '861648',
                        '861650',
                        '861652',
                        '861654',
                        '876514',
                        '884383',
                        '904458',
                        '904460',
                        '904467',
                        '904469',
                        '904475',
                        '904477',
                        '904481',
                        '904483',
                        '904660',
                        '904661',
                        '904664',
                        '904665',
                        '904668',
                        '904669',
                        '997004',
                        '997006',
                        '997007',
                        '999935',
                        '999936',
                        '999939',
                        '999942',
                        '999943',
                        '999946',
                        '1189803',
                        '1189804',
                        '1189805',
                        '1189808',
                        '1189809',
                        '1189814',
                        '1189818',
                        '1189821',
                        '1189822',
                        '1189827',
                        '1233869',
                        '1233870',
                        '1233871',
                        '1233878',
                        '1233883',
                        '1233888',
                        '1245420',
                        '1245430',
                        '1245441',
                        '1245449',
                        '1312409',
                        '1312410',
                        '1312415',
                        '1312416',
                        '1312417',
                        '1312422',
                        '1312423',
                        '1312424',
                        '1312429',
                        '1372731',
                        '1372754',
                        '1422085',
                        '1422086',
                        '1422087',
                        '1422092',
                        '1422093',
                        '1422095',
                        '1422096',
                        '1422098',
                        '1422099',
                        '1422101',
                        '1790679',
                        '1944257',
                        '1944262',
                        '1944264',
                        '1944266',
                        '1944734',
                        '2001252',
                        '2001254',
                        '2001255',
                        '2001260',
                        '2001262',
                        '2001264',
                        '2001266',
                        '2001268',
                        '2167557',
                        '2167558',
                        '2167563',
                        '2167565',
                        '2167567',
                        '2167569',
                        '2167571',
                        '2167573',
                        '2167575',
                        '2535745',
                        '2535747',
                        '2535748',
                        '2535749',
                        '2535750',
                        '2536055',
                        '2536060',
                        '2536062',
                        '2536064',
                        '2536066')
         group by a.patid, a.cohort
     ) as pcS;
select *
into #insulin
from (
         select a.patid, '1' as insulin, cohort
         from #pat_list a
                  left join cdm.dbo.prescribing b on a.patid = b.patid

         where b.rx_order_Date BETWEEN '2020-09-30' AND '2021-09-30'
           and rxnorm_cui in
               ('5459', '5856', '7405', '11160', '51428', '86009', '92877', '92879', '92880', '92881', '92942', '93108',
                '93332', '93398', '93555', '93557', '93558', '93560', '106888', '106889', '106891', '106892', '106893',
                '106896', '108407', '108812', '108815', '108816', '135805', '139825', '150659', '150660', '150663',
                '150664', '150667', '150831', '150973', '150974', '150975', '150977', '150978', '150979', '152599',
                '152602', '152640', '152644', '152645', '152647', '152648', '153122', '153383', '153384', '153389',
                '199040', '203209', '205314', '213441', '213442', '217573', '217704', '217705', '217707', '217708',
                '221108', '221109', '221110', '225506', '225614', '226273', '226275', '226277', '226278', '226279',
                '226280', '226281', '226282', '226283', '226290', '226291', '226292', '226293', '235275', '235278',
                '235279', '235280', '235281', '235282', '235283', '235284', '235285', '235286', '236646', '237527',
                '237528', '242120', '242916', '242917', '245265', '249134', '249220', '249296', '253181', '253182',
                '253183', '259111', '260265', '261111', '261112', '261542', '261551', '274783', '283394', '284810',
                '285018', '311016', '311019', '311020', '311021', '311025', '311026', '311027', '311028', '311030',
                '311033', '311034', '311035', '311036', '311040', '311041', '311042', '311043', '311048', '311049',
                '311050', '311051', '311052', '311053', '311054', '311055', '311056', '311057', '311058', '311059',
                '311060', '311061', '311062', '311063', '311064', '314038', '314045', '314682', '314683', '314684',
                '314685', '317235', '317598', '317800', '349673', '351297', '351857', '351858', '351859', '351860',
                '351926', '352385', '352691', '360891', '360892', '360895', '379745', '379750', '380933', '385895',
                '385902', '386086', '386088', '400008', '400560', '475968', '484322', '485210', '485277', '485280',
                '607583', '615907', '615910', '616238', '731281', '741394', '752388', '803194', '816726', '847187',
                '847189', '847191', '847195', '847197', '847199', '847201', '847203', '847205', '847207', '847209',
                '847211', '847213', '847230', '847232', '847239', '847241', '847252', '847254', '847259', '847261',
                '847263', '847265', '847278', '847279', '847417', '865098', '977837', '977840', '977842', '1007184',
                '1008501', '1309342', '1359684', '1359719', '1359720', '1359936', '1360172', '1360226', '1372685',
                '1372723', '1372741', '1372744', '1372761', '1440051', '1543202', '1543203', '1543207', '1544488',
                '1544490', '1544568', '1544569', '1544570', '1544571', '1604539', '1604540', '1604544', '1605101',
                '1652239', '1652242', '1652639', '1652640', '1652644', '1652646', '1652647', '1652648', '1653196',
                '1653198', '1653202', '1653204', '1654857', '1654858', '1654862', '1654910', '1654912', '1656705',
                '1656706', '1670007', '1670011', '1670012', '1670016', '1670021', '1670023', '1727493', '1731315',
                '1731317', '1736859', '1736863', '1798387', '1798388', '1858994', '1858995', '1858996', '1859000',
                '1860167', '1860168', '1860172', '1862101', '1862102', '1926331', '1926332', '1986350', '1986354',
                '1986356', '1992165', '1992169', '1992171', '2002419', '2002420', '2049380', '2049381', '2100028',
                '2100029', '2107520', '2107522', '2179744', '2179745', '2179749', '2205454', '2206090', '2206092',
                '2206096', '2206099', '2376838', '2377130', '2377134', '2377231', '2380231', '2380232', '2380236',
                '2380254', '2380256', '2380259', '2380260', '2563969', '2563971', '2563973', '2563976', '2563977')) as pic;
select *
into #multiple_stroke
from (
         select patid, IIF(encounter_count > 1, 1, 0) as multiple_stroke
         from (select a.patid,
                      count(a.encounterid)                                as encounter_count,
                      max(a.admit_date)                                     as max_admit_date,
                      min(a.admit_date)                                     as min_admit_date,
                      --CHECK this may be a problem... I'm trying to find the time between then first and last inpatient diagnosis
                      abs(datediff(dd, max(a.admit_date), min(a.admit_date))) as gap
               from cdm.dbo.encounter a
                        join cdm.dbo.diagnosis Como on a.encounterid = Como.encounterid

               where a.patid in (Select patid from #pat_list)
               and  encounter.admit_date<='2021-09-30'
                 and (
                       dx like '433%' -- STROKE

                       OR dx like '434%' -- STROKE

                       OR dx = '997.02' -- STROKE

                       OR dx like 'I63%' -- STROKE


                   )
                 and a.enc_Type in ('EI', 'IP')
                 -- and DRG in ('061', '062', '063', '064', '065', '066')
               group by a.patid
               having count(a.encounterid) > 1) b

         where gap
                   > 30) as pms;
select *
into #multiple_MI
from (
         select patid, gap, IIF(encounter_count > 1, 1, 0) as multiple_MI
         from (select patid,
                      count(encounterid)                                as encounter_count,
                      max(admit_date)                                     as max_admit_date,
                      min(admit_date)                                     as min_admit_date,
                      abs(datediff(dd, max(admit_date), min(admit_date))) as gap
               from cdm.dbo.diagnosis como
--join cdm.dbo.diagnosis  Como using (patid, encounterid)

               where patid in (Select patid from #pat_list)
                 and enc_Type in ('EI', 'IP')
                 and  como.admit_date<='2021-09-30' and (((dx like '410%' -- MI

                   OR dx like 'I21%')-- MI)


                   and pdx = 'P')
                   OR dx like 'I22%') -- MI)

               group by patid
               having count(encounterid) > 1) c


         where gap
                   > 30) as pgmM;
select *
into #multiple_PCI
from (
         select patid, PCI_gap, IIF(encounter_count > 1, 1, 0) as multiple_PCI
         from (select a.patid,
                      count(b.encounterid)                                as encounter_count,

                      -- 'PCI'                             as Comorbidity_name,
                      -- 1 as PCI--,
                      -- ,   max(admit_date) as max_admit_date,
                      min(admit_date)                                     as min_admit_date,
                      abs(datediff(dd, max(admit_date), min(admit_date))) as PCI_gap
               from #pat_list a
                        left join cdm.dbo.procedures b on a.patid = b.patid
               where  b.admit_date<='2021-09-30' and PX in
                     ('92920', '92921', '92924', '92925', '92928', '92929', '92933', '92934', '92937', '92938', '92941',
                      '92943', '92944', '92973', '92974', '92975', '92978', '92979', '93571', '93572', 'C9600', 'C9601',
                      'C9602', 'C9603', 'C9604', 'C9605', 'C9606', 'C9607', 'C9608')
               group by a.patid) d
         where PCI_gap > 30) as pPgmP;
select *
into #CKD
from (select patid, IIF(egfr_2021 < 60, 1, 0) as CKD
      from #labs_all) as pC;

select *
into #combined
from (
         select distinct patid,

                         -- stroke_gap,
                         insulin,
                         PCI,
                         MI,
                         diabetes_10y,
                         stroke,
                         TIA,
                         current_smoker,
                         age_over_65,
             /*more_than_1_stroke,
             more_than_1_MI,
             more_than_1_PCI,*/
                         CAD,
                         retinopathy,
                         PAD,
                         multiple_MI,
                         multiple_stroke,
                         multiple_PCI,
                         hscrp_over_3,
                         nhdl_over_130,
                         microvascular_disease,
                         --Editing to try to fix large null counts
                         IIF(isnull(Statin, 0) = 1, 'Statin', 'No Statin')                                    as [Statin],
                         IIF((PCI + MI + stroke) > 1, 1, 0)                                        as more_than_1_of_PCI_MI_stroke,
                         IIF((PCI + MI + stroke + multiple_stroke + multiple_PCI + multiple_MI) > 1, 1,
                             0)                                                                    as more_than_1_of_PCI_MI_stroke_allowing_multiples,
                         IIF(((CAD + PAD + insulin + TIA) > 1), 1, 0)                              as more_than_1_of_CAD_insulin_PAD_TIA,
                         IIF(((microvascular_disease + insulin + diabetes_10y) > 1), 1, 0)         as more_than_1_diabetes_insulin_microvascular,

                         IIF((microvascular_disease = 1 or insulin = 1 or diabetes_10y = 1), 1, 0) as any_diabetes_10y_insulin_microvascular,

                         IIF(((microvascular_disease + insulin + diabetes_10y) >= 1 and age_over_65 = 1), 1,
                             0)                                                                    as any_diabetes_10y_insulin_microvascular_age_over_65,
                         IIF(((microvascular_disease + insulin + diabetes_10y) >= 1 and current_smoker = 1), 1,
                             0)                                                                    as any_diabetes_10y_insulin_microvascular_smoker,
                         IIF(((microvascular_disease + insulin + diabetes_10y) >= 1 and nhdl_over_130 = 1), 1,
                             0)                                                                    as any_diabetes_10y_insulin_microvascular_nhdl_over_130,
                         IIF(((microvascular_disease + insulin + diabetes_10y) >= 1 and retinopathy = 1), 1,
                             0)                                                                    as any_diabetes_10y_insulin_microvascular_retinopathy,
                         IIF(((microvascular_disease + insulin + diabetes_10y) >= 1 and hscrp_over_3 = 1), 1,
                             0)                                                                    as any_diabetes_10y_insulin_microvascular_hscrp_over_3,
                         IIF(((microvascular_disease + insulin + diabetes_10y) >= 1 and
                              hscrp_over_3 + retinopathy + nhdl_over_130 + current_smoker + age_over_65 >= 1), 1,
                             0)                                                                    as any_diabetes_10y_insulin_microvascular_plus_any,

                         IIF((microvascular_disease + insulin + diabetes_10y + hscrp_over_3 + retinopathy +
                              nhdl_over_130 +
                              current_smoker + age_over_65 + PCI + MI + stroke = 0), 1,
                             0)                                                                    as no_CV_or_risk_factors


         from (select distinct a.patid,

                               IIF(microvascular_disease = 1, 1, 0) as microvascular_disease,
                               IIF(nhdl_over_130 = 1, 1, 0)         as nhdl_over_130,
                               IIF(hscrp_over_3 = 1, 1, 0)          as hscrp_over_3,

                               IIF(retinopathy = 1, 1, 0)           as retinopathy,

                               -- stroke_gap,
                               coalesce(Statin,0)					as Statin,

                               IIF(diabetes_10y = 1, 1, 0)          as diabetes_10y,
                               IIF(insulin = 1, 1, 0)               as insulin,
                               IIF(TIA = 1, 1, 0)                   as TIA,
                               IIF(PAD = 1, 1, 0)                   as PAD,
                               IIF(CAD = 1, 1, 0)                   as CAD,
                               IIF(PCI = 1, 1, 0)                   as PCI,
                               IIF(MI = 1, 1, 0)                    as MI,
                               IIF(stroke = 1, 1, 0)                as stroke,
                               IIF(multiple_PCI = 1, 1, 0)          as multiple_PCI,
                               IIF(multiple_MI = 1, 1, 0)           as multiple_MI,
                               IIF(multiple_stroke = 1, 1, 0)       as multiple_stroke
                       ,
                               IIF(current_smoker = 1, 1, 0)        as current_smoker,
                               IIF(age_over_65 = 1, 1, 0)           as age_over_65
               from #pat_list a
                        full outer join #MI b on a.patid = b.patid
                        full outer join #PCI c on a.patid = c.patid
                        full outer join #statins d on a.patid = d.patid
                        full outer join #insulin e on a.patid = e.patid
                        full outer join #CAD f on a.patid = f.patid
                        full outer join #TIA g on a.patid = g.patid
                        full outer join #PAD h on a.patid = h.patid
                        full outer join #diabetes_10y i on a.patid = i.patid
                        full outer join #retinopathy j on a.patid = j.patid
                        full outer join #multiple_stroke k on a.patid = k.patid
                        full outer join #multiple_MI l on a.patid = l.patid
                        full outer join #multiple_PCI m on a.patid = m.patid
                        full outer join #smoking n on a.patid = n.patid
                        full outer join #age_65 o on a.patid = o.patid
                        full outer join #labs p on a.patid = p.patid
						full outer Join #stroke q on  a.PATID = q.PATID
              ) f) as f2;


select a.cohort,
       sum(PCI)                                                  as N_PCI,
       sum(MI)                                                   as N_MI,
       sum(stroke)                                               as N_stroke,
       sum(more_than_1_of_PCI_MI_stroke)                         as N_more_than_1_of_PCI_MI_stroke,
       sum(multiple_stroke)                                      as N_more_than_1_stroke,
       sum(multiple_MI)                                          as N_more_than_1_MI,
       sum(multiple_PCI)                                         as N_more_than_1_PCI,
       sum(more_than_1_of_PCI_MI_stroke_allowing_multiples)      as N_more_than_1_of_PCI_MI_stroke_allowing_multiples
        ,
       Statin,
       sum(insulin)                                              as N_insulin,
       sum(CAD)                                                  as N_CAD,
       sum(TIA)                                                  as N_TIA,
       sum(PAD)                                                  as N_PAD,
       sum(diabetes_10y)                                         as N_diabetes_10y,
       sum(retinopathy)                                          as N_retinopathy,
       sum(more_than_1_of_CAD_insulin_PAD_TIA)                   as N_more_than_1_of_CAD_insulin_PAD_TIA,
       sum(current_smoker)                                       as N_current_smoker,
       sum(age_over_65)                                          as N_age_over_65,
       sum(hscrp_over_3)                                         as N_hscrp_over_3,
       sum(nhdl_over_130)                                        as N_nhdl_over_130,
       sum(microvascular_disease)                                as N_microvascular_disease,
       sum(more_than_1_of_CAD_insulin_PAD_TIA)                   as N_more_than_1_of_CAD_insulin_PAD_TIA,
       sum(more_than_1_diabetes_insulin_microvascular)           as N_more_than_1_diabetes_insulin_microvascular,
       sum(any_diabetes_10y_insulin_microvascular)               as N_any_diabetes_10y_insulin_microvascular,
       sum(any_diabetes_10y_insulin_microvascular_age_over_65)   as N_any_diabetes_10y_insulin_microvascular_age_over_65,
       sum(any_diabetes_10y_insulin_microvascular_smoker)        as N_any_diabetes_10y_insulin_microvascular_smoker,
       sum(any_diabetes_10y_insulin_microvascular_nhdl_over_130) as N_any_diabetes_10y_insulin_microvascular_nhdl_over_130,
       sum(any_diabetes_10y_insulin_microvascular_retinopathy)   as any_diabetes_10y_insulin_microvascular_retinopathy,
       sum(any_diabetes_10y_insulin_microvascular_hscrp_over_3)  as any_diabetes_10y_insulin_microvascular_hscrp_over_3,
       sum(any_diabetes_10y_insulin_microvascular_plus_any)      as N_any_diabetes_10y_insulin_microvascular_plus_any,
       sum(no_CV_or_risk_factors)                                as N_no_CV_or_risk_factors,
       count(distinct a.patid)                                   as total_count_patients

from #pat_list a
         left join #combined b on a.patid = b.patid
group by a.cohort, Statin

order by a.cohort

